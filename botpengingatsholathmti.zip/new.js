
const Telegram = require("node-telegram-bot-api");
const token = process.env["botToken"];
const bot = new Telegram(token, { polling: true });
const fs = require('fs');



    // file gambar untuk dikirim 
		// tiap variabel berupa array dari nama-nama file
		let subuh = fs.readdirSync("./gambar/subuh");
		let dzuhur = fs.readdirSync("./gambar/dzuhur");
		let ashar = fs.readdirSync("./gambar/ashar");
		let maghrib = fs.readdirSync("./gambar/maghrib");
		let isya = fs.readdirSync("./gambar/isya");

		let waktu_sholat = "ashar"
// 732056126

		bot.sendPhoto("-732056126", `gambar/ashar/${ashar[Math.floor(Math.random() * ashar.length)]}`
		// , {caption: "Selamat menunaikan sholat subuh",}
									);
