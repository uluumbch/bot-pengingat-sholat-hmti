const axios = require("axios");
const Telegram = require("node-telegram-bot-api");
// const token = "5205873843:AAGO4ToQhWhmktHecthJAZYWWoJ8gPCIWaI";
const token = process.env['botToken']
const bot = new Telegram(token, { polling: true });


bot.sendPhoto("-595669157", "gambar/dzuhur.png")
